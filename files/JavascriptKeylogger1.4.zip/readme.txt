Javascript Keylogger 1.4

Start the server, view Test1.htm or Test2.htm, and type in one of the inputs to see
it in action. Logged keystrokes are displayed in the console and written to
a text file in the same directory as the server. Server settings are in the
JavascriptKeyloggerServer.exe.config file.

Changelog
1.4
Added python server

1.3
Log entries now categorized by page view and field rather than just field
Fixed server crash bugs
Fixed bug related to replacing head & body

john.leitch5@gmail.com