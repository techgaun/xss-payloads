<?php 
/**
 * Global variables
 *
 */

$DB_LOGIN='ROOT';
$DB_PASSWORD='PASSWORD';
$HOST='localhost';
$DATABASE_NAME='Test';
$TABLE_NAME='Keylogger';

?>