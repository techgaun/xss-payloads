jack
====

ClickJacking PoC development assistance tool.

Jack is a static HTML and JavaScript web-based tool. To get Jack up and running, serve the index.html file in a manner of your choice and ClickJack away.
Be sure to check your browser settings when PoC'ing HTTPS based targets as most browsers will not allow embedding HTTPS resources into iFrames.
